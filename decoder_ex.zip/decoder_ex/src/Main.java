public class Main {
    public static void main(String[] args) {
Decoder decoder = new Decoder();
decoder.decode();
    }
}
